---
shortname: "FBK"
fullname: "FONDAZIONE BRUNO KESSLER"
country: "Italy"
role: "Beneficiary"
logo: "/images/logos/fbk.png"
website: "https://www.fbk.eu"
---
