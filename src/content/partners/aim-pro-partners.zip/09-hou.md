---
shortname: "HOU"
fullname: "HELLENIC OPEN UNIVERSITY"
country: "Greece"
role: "Beneficiary"
logo: "/images/logos/hou.png"
website: "https://www.eap.gr"
---
