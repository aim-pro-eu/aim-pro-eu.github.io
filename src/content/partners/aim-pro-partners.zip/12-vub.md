---
shortname: "VUB"
fullname: "VRIJE UNIVERSITEIT BRUSSEL"
country: "Belgium"
role: "Beneficiary"
logo: "/images/logos/vub.png"
website: "https://www.vub.be"
---
