---
shortname: "REN"
fullname: "UNIVERSITE DE RENNES"
country: "France"
role: "Beneficiary"
logo: "/images/logos/ren.png"
website: "https://www.univ-rennes.fr"
---
