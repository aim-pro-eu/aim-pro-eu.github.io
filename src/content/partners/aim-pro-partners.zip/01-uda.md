---
shortname: "UDA"
fullname: "UNIVERSITA DEGLI STUDI DELL'AQUILA"
country: "Italy"
role: "Coordinator"
logo: "/images/logos/uda.png"
website: "https://www.univaq.it"
---
