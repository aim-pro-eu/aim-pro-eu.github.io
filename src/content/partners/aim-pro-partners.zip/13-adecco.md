---
shortname: "ADECCO"
fullname: "ADECCO ITALIA SPA"
country: "Italy"
role: "Beneficiary"
logo: "/images/logos/adecco.png"
website: "https://www.adecco.it"
---
