---
shortname: "UREG"
fullname: "UNIVERSITAET REGENSBURG"
country: "Germany"
role: "Beneficiary"
logo: "/images/logos/ureg.png"
website: "https://www.uni-regensburg.de"
---
