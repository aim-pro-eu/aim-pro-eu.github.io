---
shortname: "EDT"
fullname: "Edutech S.r.l."
country: "Italy"
role: "Beneficiary"
logo: "/images/logos/edt.png"
website: "https://www.edutech.it"
---
