---
shortname: "USAL"
fullname: "UNIVERSIDAD DE SALAMANCA"
country: "Spain"
role: "Beneficiary"
logo: "/images/logos/usal.png"
website: "https://www.usal.es"
---
