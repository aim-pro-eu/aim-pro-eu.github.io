---
shortname: "MDU"
fullname: "MALARDALENS UNIVERSITET"
country: "Sweden"
role: "Beneficiary"
logo: "/images/logos/mdu.png"
website: "https://www.mdu.se"
---
