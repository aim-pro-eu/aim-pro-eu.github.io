---
shortname: "ICG"
fullname: "IZOBRAZEVALNI CENTER GEOSS DOO"
country: "Slovenia"
role: "Beneficiary"
logo: "/images/logos/icg.png"
website: "https://www.ic-geoss.si"
---
