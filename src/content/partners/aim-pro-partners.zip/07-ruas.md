---
shortname: "RUAS"
fullname: "STICHTING HOGESCHOOL ROTTERDAM"
country: "Netherlands"
role: "Beneficiary"
logo: "/images/logos/ruas.png"
website: "https://www.rotterdamuas.com"
---
