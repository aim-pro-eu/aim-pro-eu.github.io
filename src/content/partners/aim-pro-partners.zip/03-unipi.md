---
shortname: "UNIPI"
fullname: "UNIVERSITA DI PISA"
country: "Italy"
role: "Beneficiary"
logo: "/images/logos/unipi.png"
website: "https://www.unipi.it"
---
