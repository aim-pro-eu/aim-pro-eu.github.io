---
shortname: "EITCI"
fullname: "European Information Technologies Certification Institute"
country: "Belgium"
role: "Beneficiary"
logo: "/images/logos/eitci.png"
website: "https://eitci.org"
---
